CREATE DATABASE IF NOT EXISTS contact_form
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE contact_form;

CREATE TABLE IF NOT EXISTS admins (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(80) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY admins_username_unique (username)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS messages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(254) NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY messages_created_at_index (created_at),
    KEY messages_is_read_index (is_read)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS images (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    filename CHAR(37) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(32) NOT NULL,
    file_size INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY images_filename_unique (filename),
    KEY images_created_at_index (created_at)
) ENGINE=InnoDB;
