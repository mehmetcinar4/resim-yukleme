<?php
declare(strict_types=1);
require __DIR__ . '/../bootstrap.php';

if (isset($_SESSION['admin_id'])) {
    redirect('/admin/');
}

$next = $_POST['next'] ?? $_GET['next'] ?? '/admin/';
if (!is_string($next) || !in_array($next, ['/admin/', '/admin/images.php'], true)) {
    $next = '/admin/';
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (is_string($username) && is_string($password)) {
        $statement = db()->prepare('SELECT id, username, password_hash FROM admins WHERE username = :username');
        $statement->execute(['username' => trim($username)]);
        $admin = $statement->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int) $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            redirect($next);
        }
    }

    $error = 'Kullanıcı adı veya parola hatalı.';
}
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Yönetici girişi</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body class="auth-page">
<main class="auth-shell">
    <section class="auth-aside">
        <a class="brand" href="/admin/login.php"><span class="brand-mark">K</span> Koleksiyon</a>
        <div class="auth-aside-copy">
            <span class="eyebrow">GÜVENLİ YÖNETİM ALANI</span>
            <h1>Görselleriniz,<br>tek bir yerde.</h1>
            <p>Fotoğraflarınızı yükleyin, düzenleyin ve paylaşılabilir bağlantıları kolayca alın.</p>
        </div>
        <span class="aside-footnote">Özel alan · Yalnızca yetkili kullanıcılar</span>
    </section>
    <section class="auth-content">
        <div class="auth-card">
            <span class="auth-icon" aria-hidden="true">↗</span>
            <p class="eyebrow">HOŞ GELDİNİZ</p>
            <h2>Hesabınıza giriş yapın</h2>
            <p class="auth-description">Devam etmek için yönetici bilgilerinizle oturum açın.</p>
            <?php if ($error !== ''): ?>
                <div class="notice error" role="alert"><?= e($error) ?></div>
            <?php endif; ?>
            <form method="post" action="/admin/login.php">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="next" value="<?= e($next) ?>">
                <label for="username">Kullanıcı adı</label>
                <input id="username" name="username" autocomplete="username" placeholder="Kullanıcı adınız" required>
                <label for="password">Parola</label>
                <input id="password" name="password" type="password" autocomplete="current-password" placeholder="Parolanız" required>
                <button class="auth-submit" type="submit">Güvenli giriş yap <span aria-hidden="true">→</span></button>
            </form>
            <a class="auth-back" href="/">← İletişim formuna dön</a>
        </div>
        <span class="auth-copyright">© <?= date('Y') ?> Koleksiyon. Güvenli giriş.</span>
    </section>
</main>
</body>
</html>
