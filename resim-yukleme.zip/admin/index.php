<?php
declare(strict_types=1);
require __DIR__ . '/../bootstrap.php';
require_admin();

$pdo = db();
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    if ($id === false || $id === null) {
        http_response_code(400);
        exit('Geçersiz mesaj numarası.');
    }

    if ($action === 'delete') {
        $statement = $pdo->prepare('DELETE FROM messages WHERE id = :id');
        $statement->execute(['id' => $id]);
        $_SESSION['admin_notice'] = $statement->rowCount() > 0
            ? 'Mesaj silindi.'
            : 'Silinecek mesaj bulunamadı.';
    } elseif ($action === 'mark_read' || $action === 'mark_unread') {
        $statement = $pdo->prepare('UPDATE messages SET is_read = :is_read WHERE id = :id');
        $statement->execute([
            'is_read' => $action === 'mark_read' ? 1 : 0,
            'id' => $id,
        ]);
        $_SESSION['admin_notice'] = 'Mesaj durumu güncellendi.';
    } else {
        http_response_code(400);
        exit('Geçersiz işlem.');
    }

    $returnTo = '/admin/';
    if (isset($_POST['return_to']) && $_POST['return_to'] === 'detail') {
        $returnTo .= '?id=' . $id;
    }
    redirect($returnTo);
}

$notice = $_SESSION['admin_notice'] ?? '';
unset($_SESSION['admin_notice']);
$selectedId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$message = null;

if ($selectedId !== null && $selectedId !== false) {
    $statement = $pdo->prepare('SELECT * FROM messages WHERE id = :id');
    $statement->execute(['id' => $selectedId]);
    $message = $statement->fetch();
}

$messages = $pdo->query(
    'SELECT id, name, email, subject, is_read, created_at FROM messages ORDER BY created_at DESC, id DESC LIMIT 100'
)->fetchAll();
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mesaj yönetimi</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="container wide">
    <header class="topbar">
        <div>
            <h1>İletişim mesajları</h1>
            <p>Merhaba, <?= e((string) ($_SESSION['admin_username'] ?? 'Yönetici')) ?></p>
        </div>
        <div class="topbar-actions">
            <a class="button-link secondary" href="/admin/images.php">Görsel galerisi</a>
            <form method="post" action="/admin/logout.php">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <button class="secondary" type="submit">Çıkış yap</button>
            </form>
        </div>
    </header>

    <?php if ($notice !== ''): ?>
        <div class="notice success" role="status"><?= e($notice) ?></div>
    <?php endif; ?>

    <?php if ($selectedId !== null && $selectedId !== false): ?>
        <?php if ($message): ?>
            <section class="card detail">
                <a href="/admin/">← Tüm mesajlar</a>
                <h2><?= e($message['subject']) ?></h2>
                <p><strong>Gönderen:</strong> <?= e($message['name']) ?> &lt;<a href="mailto:<?= e($message['email']) ?>"><?= e($message['email']) ?></a>&gt;</p>
                <p><strong>Tarih:</strong> <?= e($message['created_at']) ?></p>
                <div class="message-body"><?= nl2br(e($message['message'])) ?></div>
                <div class="actions">
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="id" value="<?= (int) $message['id'] ?>">
                        <input type="hidden" name="return_to" value="detail">
                        <input type="hidden" name="action" value="<?= $message['is_read'] ? 'mark_unread' : 'mark_read' ?>">
                        <button class="secondary" type="submit"><?= $message['is_read'] ? 'Okunmadı işaretle' : 'Okundu işaretle' ?></button>
                    </form>
                    <form method="post" onsubmit="return confirm('Bu mesaj silinsin mi?')">
                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="id" value="<?= (int) $message['id'] ?>">
                        <input type="hidden" name="return_to" value="list">
                        <input type="hidden" name="action" value="delete">
                        <button class="danger" type="submit">Mesajı sil</button>
                    </form>
                </div>
            </section>
        <?php else: ?>
            <div class="notice error">Mesaj bulunamadı.</div>
        <?php endif; ?>
    <?php endif; ?>

    <section class="card">
        <h2>Son mesajlar <span class="muted">(en fazla 100)</span></h2>
        <?php if ($messages === []): ?>
            <p>Henüz mesaj gönderilmemiş.</p>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr><th>Durum</th><th>Gönderen</th><th>Konu</th><th>Tarih</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach ($messages as $item): ?>
                        <tr class="<?= $item['is_read'] ? '' : 'unread' ?>">
                            <td><?= $item['is_read'] ? 'Okundu' : 'Yeni' ?></td>
                            <td><?= e($item['name']) ?><br><span class="muted"><?= e($item['email']) ?></span></td>
                            <td><a href="/admin/?id=<?= (int) $item['id'] ?>"><?= e($item['subject']) ?></a></td>
                            <td><?= e($item['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
