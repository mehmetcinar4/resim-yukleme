<?php
declare(strict_types=1);
require __DIR__ . '/../bootstrap.php';
require_admin('/admin/images.php');

$pdo = db();
$errors = [];
$notice = $_SESSION['image_notice'] ?? '';
unset($_SESSION['image_notice']);
$uploadDirectory = __DIR__ . '/../uploads';
$maxFileSize = 10 * 1024 * 1024;
$allowedTypes = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/gif' => 'gif',
    'image/webp' => 'webp',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'upload') {
        $file = $_FILES['image'] ?? null;
        if (!is_array($file) || !isset($file['error'], $file['tmp_name'], $file['size'], $file['name'])) {
            $errors[] = 'Yüklenecek bir görsel seçin.';
        } elseif ((int) $file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = match ((int) $file['error']) {
                UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Görsel en fazla 10 MB olabilir.',
                UPLOAD_ERR_NO_FILE => 'Lütfen bir görsel seçin.',
                default => 'Görsel yüklenemedi. Lütfen tekrar deneyin.',
            };
        } elseif (!is_uploaded_file((string) $file['tmp_name'])) {
            $errors[] = 'Yüklenen dosya doğrulanamadı.';
        } else {
            $temporaryPath = (string) $file['tmp_name'];
            $fileSize = filesize($temporaryPath);
            $fileInfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $fileInfo->file($temporaryPath);
            $imageInfo = getimagesize($temporaryPath);

            if ($fileSize === false || $fileSize < 1 || $fileSize > $maxFileSize) {
                $errors[] = 'Görsel 1 bayt ile 10 MB arasında olmalıdır.';
            } elseif (!is_string($mimeType) || !isset($allowedTypes[$mimeType]) || $imageInfo === false || ($imageInfo['mime'] ?? '') !== $mimeType) {
                $errors[] = 'Yalnızca JPEG, PNG, GIF veya WebP görselleri yükleyebilirsiniz.';
            } elseif (
                $imageInfo[0] < 1
                || $imageInfo[1] < 1
                || $imageInfo[0] > 12000
                || $imageInfo[1] > 12000
                || $imageInfo[0] > intdiv(40000000, $imageInfo[1])
            ) {
                $errors[] = 'Görsel boyutları desteklenen sınırların dışında.';
            } else {
                if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
                    throw new RuntimeException('Görsel yükleme klasörü oluşturulamadı.');
                }

                $filename = bin2hex(random_bytes(16)) . '.' . $allowedTypes[$mimeType];
                $destination = $uploadDirectory . '/' . $filename;
                if (!move_uploaded_file($temporaryPath, $destination)) {
                    throw new RuntimeException('Görsel sunucuya kaydedilemedi.');
                }

                $originalName = basename(str_replace('\\', '/', (string) $file['name']));
                $originalName = preg_replace('/[\x00-\x1F\x7F]/', '', $originalName) ?: 'Görsel';
                if (preg_match('//u', $originalName) !== 1) {
                    $originalName = 'Görsel';
                } else {
                    $originalName = preg_replace('/^(.{0,255}).*$/us', '$1', $originalName) ?: 'Görsel';
                }
                $statement = $pdo->prepare(
                    'INSERT INTO images (filename, original_name, mime_type, file_size) VALUES (:filename, :original_name, :mime_type, :file_size)'
                );

                try {
                    $statement->execute([
                        'filename' => $filename,
                        'original_name' => $originalName,
                        'mime_type' => $mimeType,
                        'file_size' => $fileSize,
                    ]);
                } catch (Throwable $exception) {
                    if (!unlink($destination)) {
                        error_log('Could not remove an image after its database insert failed: ' . $destination);
                    }
                    throw $exception;
                }

                $_SESSION['image_notice'] = 'Görsel başarıyla yüklendi.';
                redirect('/admin/images.php');
            }
        }
    } elseif ($action === 'delete') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false || $id === null) {
            http_response_code(400);
            exit('Geçersiz görsel numarası.');
        }

        $statement = $pdo->prepare('SELECT filename FROM images WHERE id = :id');
        $statement->execute(['id' => $id]);
        $image = $statement->fetch();
        if (!$image) {
            $_SESSION['image_notice'] = 'Silinecek görsel bulunamadı.';
        } elseif (!preg_match('/\A[a-f0-9]{32}\.(?:jpg|png|gif|webp)\z/', $image['filename'])) {
            throw new RuntimeException('Görsel dosya adı doğrulanamadı.');
        } else {
            $imagePath = $uploadDirectory . '/' . $image['filename'];
            if (is_file($imagePath) && !unlink($imagePath)) {
                throw new RuntimeException('Görsel dosyası silinemedi.');
            }
            $statement = $pdo->prepare('DELETE FROM images WHERE id = :id');
            $statement->execute(['id' => $id]);
            $_SESSION['image_notice'] = 'Görsel silindi.';
        }

        redirect('/admin/images.php');
    } else {
        http_response_code(400);
        exit('Geçersiz işlem.');
    }
}

$images = $pdo->query('SELECT id, filename, original_name, mime_type, file_size, created_at FROM images ORDER BY created_at DESC, id DESC')->fetchAll();
$totalSize = array_sum(array_column($images, 'file_size'));
$formatSize = static function (int $bytes): string {
    if ($bytes >= 1024 * 1024) {
        return number_format($bytes / (1024 * 1024), 1, ',', '.') . ' MB';
    }
    return number_format(max(1, (int) ceil($bytes / 1024)), 0, ',', '.') . ' KB';
};
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Görsel galerisi · Koleksiyon</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body class="gallery-page">
<main class="gallery-shell">
    <header class="gallery-nav">
        <a class="brand" href="/admin/images.php"><span class="brand-mark">K</span> Koleksiyon</a>
        <nav class="gallery-nav-links" aria-label="Yönetim">
            <a class="nav-link active" href="/admin/images.php">Görseller</a>
            <a class="nav-link" href="/admin/">Mesajlar</a>
            <span class="user-chip" aria-label="Oturum açan kullanıcı: <?= e((string) ($_SESSION['admin_username'] ?? 'Yönetici')) ?>">
                <span class="user-avatar"><?= e(strtoupper(substr((string) ($_SESSION['admin_username'] ?? 'Y'), 0, 1))) ?></span>
                <span class="user-name"><?= e((string) ($_SESSION['admin_username'] ?? 'Yönetici')) ?></span>
            </span>
            <form method="post" action="/admin/logout.php">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <button class="logout-button" type="submit">Çıkış yap</button>
            </form>
        </nav>
    </header>

    <section class="gallery-heading">
        <div>
            <p class="eyebrow">GÖRSEL KÜTÜPHANENİZ</p>
            <h1>Her kare, elinizin altında.</h1>
            <p class="gallery-subtitle">Görsellerinizi yükleyin, görüntüleyin ve bağlantılarını paylaşın.</p>
        </div>
        <div class="gallery-stats">
            <div><strong><?= count($images) ?></strong><span>görsel</span></div>
            <div><strong><?= e($formatSize((int) $totalSize)) ?></strong><span>kullanımda</span></div>
        </div>
    </section>

    <?php if ($notice !== ''): ?>
        <div class="notice success" role="status"><?= e($notice) ?></div>
    <?php endif; ?>
    <?php if ($errors !== []): ?>
        <div class="notice error" role="alert">
            <ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul>
        </div>
    <?php endif; ?>

    <section class="upload-panel">
        <div class="upload-copy">
            <span class="upload-icon" aria-hidden="true">↑</span>
            <div>
                <h2>Yeni görsel ekle</h2>
                <p>JPEG, PNG, GIF veya WebP · En fazla 10 MB</p>
            </div>
        </div>
        <form class="upload-form" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="upload">
            <input type="hidden" name="MAX_FILE_SIZE" value="<?= $maxFileSize ?>">
            <label class="file-picker" for="image">
                <span id="file-name">Dosya seçin</span>
                <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/gif,image/webp" required>
            </label>
            <button class="upload-button" type="submit">Görseli yükle <span aria-hidden="true">↗</span></button>
        </form>
    </section>

    <div class="gallery-section-heading">
        <div>
            <h2>Yüklenen görseller</h2>
            <p><?= count($images) > 0 ? 'Bir görsele tıklayarak büyük görüntüleyin.' : 'Galerinizde henüz görsel yok.' ?></p>
        </div>
    </div>

    <?php if ($images === []): ?>
        <section class="empty-gallery">
            <span class="empty-icon" aria-hidden="true">▧</span>
            <h3>Galeriniz burada şekillenecek</h3>
            <p>İlk görselinizi yükleyerek başlayın. Yüklediğiniz görsellerin bağlantılarını tek tıkla kopyalayabilirsiniz.</p>
        </section>
    <?php else: ?>
        <section class="image-grid" aria-label="Yüklenen görseller">
            <?php foreach ($images as $image): ?>
                <?php $imageUrl = '/uploads/' . rawurlencode($image['filename']); ?>
                <article class="image-card">
                    <button class="image-preview" type="button" data-lightbox-src="<?= e($imageUrl) ?>" data-lightbox-alt="<?= e($image['original_name']) ?>" aria-label="<?= e($image['original_name']) ?> görselini büyüt">
                        <img src="<?= e($imageUrl) ?>" alt="<?= e($image['original_name']) ?>" loading="lazy">
                        <span class="preview-hint" aria-hidden="true">Büyüt ↗</span>
                    </button>
                    <div class="image-card-info">
                        <div class="image-meta">
                            <strong title="<?= e($image['original_name']) ?>"><?= e($image['original_name']) ?></strong>
                            <span><?= e($formatSize((int) $image['file_size'])) ?> · <?= e(date('d.m.Y', strtotime($image['created_at']))) ?></span>
                        </div>
                        <div class="image-actions">
                            <button class="copy-button" type="button" data-copy-link="<?= e($imageUrl) ?>">Linki kopyala</button>
                            <form method="post" onsubmit="return confirm('Bu görsel kalıcı olarak silinsin mi?')">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int) $image['id'] ?>">
                                <button class="delete-button" type="submit" aria-label="<?= e($image['original_name']) ?> görselini sil" title="Görseli sil">Sil</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>
    <footer class="gallery-footer">Görselleriniz güvenli yönetim alanınızda saklanır.</footer>
</main>

<dialog class="lightbox" id="lightbox" aria-label="Büyük görsel">
    <button class="lightbox-close" type="button" aria-label="Kapat">×</button>
    <img id="lightbox-image" src="" alt="">
</dialog>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<script>
    const fileInput = document.getElementById('image');
    fileInput.addEventListener('change', () => {
        document.getElementById('file-name').textContent = fileInput.files[0]?.name || 'Dosya seçin';
    });

    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    document.querySelectorAll('[data-lightbox-src]').forEach((button) => {
        button.addEventListener('click', () => {
            lightboxImage.src = button.dataset.lightboxSrc;
            lightboxImage.alt = button.dataset.lightboxAlt;
            lightbox.showModal();
        });
    });
    document.querySelector('.lightbox-close').addEventListener('click', () => lightbox.close());
    lightbox.addEventListener('click', (event) => {
        if (event.target === lightbox) lightbox.close();
    });
    lightbox.addEventListener('close', () => {
        lightboxImage.src = '';
        lightboxImage.alt = '';
    });

    let toastTimer;
    const toast = document.getElementById('toast');
    document.querySelectorAll('[data-copy-link]').forEach((button) => {
        button.addEventListener('click', async () => {
            const link = new URL(button.dataset.copyLink, window.location.origin).href;
            try {
                await navigator.clipboard.writeText(link);
                toast.textContent = 'Görsel bağlantısı kopyalandı.';
                toast.classList.add('visible');
                window.clearTimeout(toastTimer);
                toastTimer = window.setTimeout(() => toast.classList.remove('visible'), 2600);
            } catch {
                toast.textContent = 'Bağlantı kopyalanamadı. Tarayıcı izinlerini kontrol edin.';
                toast.classList.add('visible', 'toast-error');
                window.clearTimeout(toastTimer);
                toastTimer = window.setTimeout(() => toast.classList.remove('visible', 'toast-error'), 3200);
            }
        });
    });
</script>
</body>
</html>
