<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$errors = [];
$values = ['name' => '', 'email' => '', 'subject' => '', 'message' => ''];
$success = $_SESSION['contact_success'] ?? false;
unset($_SESSION['contact_success']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    foreach ($values as $key => $_) {
        $posted = $_POST[$key] ?? '';
        $values[$key] = is_string($posted) ? trim($posted) : '';
    }

    if ($values['name'] === '' || character_length($values['name']) > 120) {
        $errors[] = 'Ad soyad alanı zorunludur (en fazla 120 karakter).';
    }
    if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL) || strlen($values['email']) > 254) {
        $errors[] = 'Geçerli bir e-posta adresi girin.';
    }
    if ($values['subject'] === '' || character_length($values['subject']) > 200) {
        $errors[] = 'Konu alanı zorunludur (en fazla 200 karakter).';
    }
    if ($values['message'] === '' || strlen($values['message']) > 20000) {
        $errors[] = 'Mesaj alanı zorunludur (en fazla 20.000 bayt).';
    }

    if ($errors === []) {
        $statement = db()->prepare(
            'INSERT INTO messages (name, email, subject, message) VALUES (:name, :email, :subject, :message)'
        );
        $statement->execute($values);
        $_SESSION['contact_success'] = true;
        redirect('/');
    }
}
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>İletişim</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="container">
    <section class="card">
        <h1>Bizimle iletişime geçin</h1>
        <p>Mesajınızı gönderin, en kısa sürede size dönüş yapalım.</p>

        <?php if ($success): ?>
            <div class="notice success" role="status">Mesajınız başarıyla gönderildi.</div>
        <?php endif; ?>
        <?php if ($errors !== []): ?>
            <div class="notice error" role="alert">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= e($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="/">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <label for="name">Ad soyad</label>
            <input id="name" name="name" maxlength="120" autocomplete="name" required value="<?= e($values['name']) ?>">

            <label for="email">E-posta</label>
            <input id="email" name="email" type="email" maxlength="254" autocomplete="email" required value="<?= e($values['email']) ?>">

            <label for="subject">Konu</label>
            <input id="subject" name="subject" maxlength="200" required value="<?= e($values['subject']) ?>">

            <label for="message">Mesajınız</label>
            <textarea id="message" name="message" rows="7" maxlength="20000" required><?= e($values['message']) ?></textarea>

            <button type="submit">Mesajı gönder</button>
        </form>
    </section>
</main>
</body>
</html>
